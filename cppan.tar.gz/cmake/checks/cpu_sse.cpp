#include <xmmintrin.h>
int main() { return 0; }
